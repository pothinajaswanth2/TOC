/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

char input[100];
int i = 0;

void error() {
    printf("Invalid input!\n");
    exit(1);
}

void expr();
void term();
void factor();
void number();

void expr() {
    term();
    while (input[i] == '+' || input[i] == '-') {
        i++;
        term();
    }
}

void term() {
    factor();
    while (input[i] == '*' || input[i] == '/') {
        i++;
        factor();
    }
}

void factor() {
    if (isdigit(input[i])) {
        number();
    }
    else if (input[i] == '(') {
        i++;
        expr();
        if (input[i] == ')') {
            i++;
        }
        else {
            error();
        }
    }
    else {
        error();
    }
}

void number() {
    while (isdigit(input[i])) {
        i++;
    }
}

int main() {
    printf("Enter an arithmetic expression: ");
    fgets(input, 100, stdin);
    input[strcspn(input, "\n")] = 0;

    expr();

    if (i == strlen(input)) {
        printf("Valid input!\n");
    }
    else {
        error();
    }

    return 0;
}