/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

struct Production
{
    char left;    // Left-hand side of the rule
    string right; // Right-hand side of the rule
};

vector<Production> remove_ambiguity(const vector<Production> &grammar)
{
    vector<Production> new_grammar; // Vector to hold the new, unambiguous grammar
    for (const auto &rule : grammar)
    {
        if (rule.right.length() <= 2 || rule.right[1] != rule.left)
        {
            new_grammar.push_back(rule);
        }
        else
        {
            char new_left = 'A';
            while (find_if(new_grammar.begin(), new_grammar.end(),
                           [new_left](const Production &p)
                           { return p.left == new_left; }) != new_grammar.end())
            {
                new_left++;
            }
            new_grammar.push_back({rule.left, string() + rule.right[0] + new_left});
            new_grammar.push_back({new_left, rule.right.substr(1)});
        }
    }
    return new_grammar;
}

int main()
{
    vector<Production> grammar = {
        {'S', "aA | aB"},
        {'A', "aA |b"},
        {'B', "aB|b"}};

    cout << "Original grammar:\n";
    for (const auto &rule : grammar)
    {
        cout << rule.left << " -> " << rule.right << endl;
    }

    vector<Production> unambiguous_grammar = remove_ambiguity(grammar);

    cout << "Grammar after removing ambiguity:\n";
    for (const auto &rule : unambiguous_grammar)
    {
        cout << rule.left << " -> " << rule.right << endl;
    }
    return 0;
}