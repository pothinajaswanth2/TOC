#include <iostream>
#include <unordered_map>
#include <vector>
#include <set>

using namespace std;

unordered_map<char, vector<string>> grammar = {
    {'S', {"AB", "BC"}},
    {'A', {"aB", "ab"}},
    {'B', {"b", "BC"}},
    {'C', {"cC", "c"}}
};

// Compute the first set of a given non-terminal symbol
set<char> compute_first(char symbol) {
    set<char> first_set;
    for (const auto &production : grammar[symbol]) {
        if (isupper(production[0])) {
            set<char> sub_first_set = compute_first(production[0]);
            first_set.insert(sub_first_set.begin(), sub_first_set.end());
        } else {
            first_set.insert(production[0]);
        }
    }
    return first_set;
}

// Compute the follow set of a given non-terminal symbol
set<char> compute_follow(char symbol) {
    set<char> follow_set;
    if (symbol == 'S') {
        follow_set.insert('$');
    }
    for (const auto &kv : grammar) {
        for (const auto &production : kv.second) {
            for (int i = 0; i < production.length(); ++i) {
                if (production[i] == symbol) {
                    if (i == production.length() - 1) {
                        if (kv.first != symbol) {
                            set<char> sub_follow_set = compute_follow(kv.first);
                            follow_set.insert(sub_follow_set.begin(), sub_follow_set.end());
                        }
                    } else {
                        if (isupper(production[i + 1])) {
                            set<char> sub_first_set = compute_first(production[i + 1]);
                            if (sub_first_set.find('e') != sub_first_set.end()) {
                                sub_first_set.erase('e');
                                set<char> sub_follow_set = compute_follow(kv.first);
                                sub_first_set.insert(sub_follow_set.begin(), sub_follow_set.end());
                                follow_set.insert(sub_first_set.begin(), sub_first_set.end());
                            } else {
                                follow_set.insert(sub_first_set.begin(), sub_first_set.end());
                            }
                        } else {
                            follow_set.insert(production[i + 1]);
                        }
                    }
                }
            }
        }
    }
    return follow_set;
}
int main() {
    // Compute and output the first and follow sets of the non-terminals
    for (const auto &kv : grammar) {
        cout << "First(" << kv.first << ") = { ";
        set<char> first_set = compute_first(kv.first);
        for (char symbol : first_set) {
            cout << symbol << " ";
        }
        cout << "}" << endl;
        cout << "Follow(" << kv.first << ") = { ";
        set<char> follow_set = compute_follow(kv.first);
        for (char symbol : follow_set) {
            cout << symbol << " ";
        }
        cout << "}" << endl;
    }
    return 0;
}
