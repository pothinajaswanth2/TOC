/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_PRODUCTIONS 100
#define MAX_SYMBOLS 100

int production_count = 0;
char productions[MAX_PRODUCTIONS][MAX_SYMBOLS];

void add_production(const char *lhs, const char *rhs)
{
    char production[MAX_SYMBOLS];
    snprintf(production, MAX_SYMBOLS, "%s%s", lhs, rhs);
    for (int i = 0; i < production_count; i++) {
        if (strcmp(production, productions[i]) == 0) {
            return; // already exists
        }
    }
    strcpy(productions[production_count], production);
    production_count++;
}

void generate_grammar(const char *regex, const char *symbol)
{
    if (*regex == '\0') {
        add_production(symbol, ""); // empty string
        return;
    }
    char first = *regex;
    char rest[MAX_SYMBOLS];
    strcpy(rest, regex + 1);
    if (rest == '*') {
        // A* -> A A*
        char non_terminal[2] = {0};
        snprintf(non_terminal, 2, "%d", production_count);
        add_production(symbol, non_terminal);
        add_production(non_terminal, ""); // empty string
        generate_grammar(rest + 1, non_terminal);
        add_production(non_terminal, non_terminal);
    } else {
        // A -> a A' | a
        char non_terminal[2] = {0};
        snprintf(non_terminal, 2, "%d", production_count);
        char terminal[2] = {0};
        snprintf(terminal, 2, "%c", first);
        add_production(symbol, terminal);
        generate_grammar(rest, non_terminal);
        add_production(non_terminal, ""); // empty string
        add_production(symbol, non_terminal);
    }
}

int main()
{
    char regex[MAX_SYMBOLS];
    printf("Enter a regular expression: ");
    scanf("%s", regex);
    generate_grammar(regex, "S");
    FILE *file = fopen("grammar.txt", "w");
    for (int i = 0; i < production_count; i++) {
        fprintf(file, "%s", productions[i]);
        if (i < production_count - 1) {
            fprintf(file, " | ");
        }
    }
    fclose(file);
    printf("Grammar generated and written to grammar.txt\n");
    return 0;
}
