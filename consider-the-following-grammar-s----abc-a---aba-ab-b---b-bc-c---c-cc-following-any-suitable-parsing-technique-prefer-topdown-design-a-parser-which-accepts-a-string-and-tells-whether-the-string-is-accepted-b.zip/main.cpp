/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <string>
using namespace std;

// Declare the recursive parsing functions
bool parseS(string input);
bool parseA(string input);
bool parseB(string input);
bool parseC(string input);

// Main function
int main() {
    string input;
    cout << "Enter a string to parse: ";
    cin >> input;
    if (parseS(input)) {
        cout << "Accepted!" << endl;
    } else {
        cout << "Not accepted." << endl;
    }
    return 0;
}

// Parse the S non-terminal
bool parseS(string input) {
    if (input.empty()) {
        // Input string is empty
        return false;
    }
    if (input[0] == 'a') {
        // Try to parse an A production
        return parseA(input.substr(1));
    } else {
        // Invalid input
        return false;
    }
}

// Parse the A non-terminal
bool parseA(string input) {
    if (input.empty()) {
        // Input string is empty
        return false;
    }
    if (input[0] == 'a') {
        // Try to parse an abA production
        if (input.length() >= 3 && input[1] == 'b' && parseA(input.substr(2))) {
            return true;
        } else {
            return false;
        }
    } else if (input[0] == 'b') {
        // Try to parse a b production
        return parseB(input.substr(1));
    } else {
        // Invalid input
        return false;
    }
}

// Parse the B non-terminal
bool parseB(string input) {
    if (input.empty()) {
        // Input string is empty
        return false;
    }
    if (input[0] == 'b') {
        // Try to parse a b production
        return parseB(input.substr(1));
    } else if (input[0] == 'c') {
        // Try to parse a BC production
        if (parseC(input.substr(1))) {
            return true;
        } else {
            return false;
        }
    } else {
        // Invalid input
        return false;
    }
}

// Parse the C non-terminal
bool parseC(string input) {
    if (input.empty()) {
        // Input string is empty
        return false;
    }
    if (input[0] == 'c') {
        // Try to parse a c production
        return parseC(input.substr(1));
    } else if (input[0] == 'a' || input[0] == 'b') {
        // Invalid input
        return false;
    } else {
        // Try to parse a cC production
        if (parseC(input.substr(1))) {
            return true;
        } else {
            return false;
        }
    }
}
